const mongoose = require("mongoose");
const validator = require("validator");

const jobSchema = new mongoose.Schema(
  {
    jobtitle: {
      type: String,
      required: [true, "Please Tell jobtitle"],
    },
    jobdescription: {
      type: String,
      required: [true, "Please Tell jobdescription"],
    },
    area: {
      type: String,
      required: [true, "Please Tell area"],
    },
    city: {
      type: String,
      required: [true, "Please Tell city"],
    },
    state: {
      type: String,
      required: [true, "Please Tell state"],
    },
    country: {
      type: String,
      required: [true, "Please Tell country"],
    },
    company: {
      type: String,
      required: [true, "Please Tell company"],
    },
    position_no: {
      type: Number,
      required: [true, "Please Tell position_no"],
    },
    minex: {
      type: Number,
      required: [true, "Please Tell minex"],
    },
    maxex: {
      type: Number,
      required: [true, "Please Tell manex"],
    },
    minsal: {
      type: Number,
      required: [true, "Please Tell minsal"],
    },
    maxsal: {
      type: Number,
      required: [true, "Please Tell maxsal"],
    },
    Applications: [
      {
        type: mongoose.Schema.ObjectId,
        ref: "Application",
      },
    ],
    Jobcreator: {
      type: String,
      required: [true, "Somthing Goes Wrong"],
    },
    creatadeAt: {
      type: Date,
      default: Date.now(),
    },
  },
  {
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

jobSchema.virtual("Jobstatus").get(function () {
  if (Date.now() - this.creatadeAt > 864000) {
    return true;
  } else {
    return false;
  }
});
const Job = mongoose.model("Job", jobSchema);

module.exports = Job;
