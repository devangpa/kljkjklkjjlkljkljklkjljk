const mongoose = require("mongoose");
const applicationSchema = new mongoose.Schema({
  jobId: {
    type: mongoose.Schema.ObjectId,
    ref: "Job",
  },
  Applicantid: {
    type: mongoose.Schema.ObjectId,
    ref: "User",
  },
  ApplicationStatus: {
    type: String,
    required: [true, "somthing went wrong"],
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const Application = mongoose.model("Application", applicationSchema);

module.exports = Application;
