const express = require("express");
const applicationController = require("./../controllers/applicationController");
const router = express.Router();

//Authentication routes
router.post("/application", applicationController.appliedonjob);

module.exports = router;
