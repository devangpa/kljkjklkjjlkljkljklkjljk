const express = require("express");
const jobController = require("./../controllers/jobcontroller");
const router = express.Router();

//Authentication routes
router.post("/job", jobController.createJob);
router.get("/jobs", jobController.Jobs);
module.exports = router;
