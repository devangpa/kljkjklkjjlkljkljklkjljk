const User = require('./../models/userModel');
const jwt = require('jsonwebtoken');
const { findOneAndUpdate } = require('./../models/userModel');

// const signToken = id => {
//     return jwt.sign({ id }, 90, {
//       expiresIn: 90
//     });
//   };

  const createSendToken = (user, statusCode, res) => {
    const token = signToken(user._id);

    res.status(statusCode).json({
      status: 'success',
      token,
      data: {
        user
      }
    });
  };

  const signToken = id => {
    return jwt.sign({ id }, "90d", {
      expiresIn: "90d"
    });
  };

exports.signup = async(req,res)=>{
    try{
        const newUser = await User.create({
            name: req.body.name,
            email: req.body.email,
            photo:req.body.photo,
            role:req.body.role,
            mobile:req.body.mobile
          });
        //   let tokan = await jwt.sign()
        res.status(201).json({Message:"Signup Sucessfull",tokan:signToken(newUser._id)})
    }catch(err){
        res.status(400).json({Message:"Not able to Signup",Error:err})
     }
}

exports.login=async(req,res,next)=>{
    const {email}=req.body
    console.log(email)
    try{
    if(email===""){
        res.status(400).json({Message:"Provide valid Email"})
    }
    const user = await User.findOne({email:email})
    res.status(200).json({Message:"Signin Sucessfull",tokan:signToken(user._id),data:user.role})
    }catch(err){
    res.status(400).json({Message:"Not able to sign in",Error:err})
   }
   next()
}

exports.updateme=async(req,res,next)=>{

    try{
        console.log(req.body.email)
        let updateMe = await User.findOneAndUpdate({email:req.body.email},{role:req.body.role})
        if(updateMe===null){
            res.status(400).json({Message:"Not able to update"})
        }
        res.status("200").json({Message:"Updated Sucessfully",data:req.body.role})
    }catch(err){
        res.status(400).json({Message:"Not able to update",Error:err})
    }
}
