const Job = require("../models/jobModel");

exports.createJob = async (req, res, next) => {
  try {
    let createjob = await Job.create(req.body);
    res.status(200).json({ Message: "Created Sucessfully", data: createjob });
  } catch (e) {
    res.status(400).json({ Message: "Not Able To create", error: e });
  }
};

exports.Jobs = async (req, res, next) => {
  try {
    let jobs = await Job.find().populate({
      path: "Applications",
      populate: { path: "Applications" },
    });
    res.status(200).json({ Message: "Created Sucessfully", data: jobs });
  } catch (e) {
    res.status(400).json({ Message: "Not Able To get", error: e });
  }
};

exports.findMycreatedJobs = async (req, res, next) => {
  try {
  } catch (e) {
    res.status(400).json({ Message: "Not Able To get", error: e });
  }
};
