import React from "react";
const Candidate = (props) => {
  return (
    <div>
      <nav class="navbar navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
          <b>Test App</b>
        </a>

        <button type="button" class="btn btn-light">
          Logout
        </button>
      </nav>
      <div class="container" style={{ margintop: "20px" }}>
        <div class="row">
          <div class="col-sm">
            {" "}
            <h6>
              <b>
                Hi {props.name}({props.role})
              </b>
            </h6>
            <hr />
            <img src={props.photo} alt="User Image" />
          </div>
          <div class="col-sm"></div>
          <div class="col-sm"></div>
        </div>
      </div>
    </div>
  );
};

export default Candidate;
